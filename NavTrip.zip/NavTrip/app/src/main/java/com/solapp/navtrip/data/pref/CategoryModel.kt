package com.solapp.navtrip.data.pref

data class CategoryModel(
    val title: String,
    val imageResId: Int
)

