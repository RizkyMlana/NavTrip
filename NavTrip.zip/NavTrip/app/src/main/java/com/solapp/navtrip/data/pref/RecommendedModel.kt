package com.solapp.navtrip.data.pref

data class RecommendedModel(
    val name: String,
    val imageResId: Int
)
